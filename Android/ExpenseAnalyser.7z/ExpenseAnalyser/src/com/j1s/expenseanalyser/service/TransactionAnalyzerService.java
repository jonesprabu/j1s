package com.j1s.expenseanalyser.service;

public class TransactionAnalyzerService {
	
	
	public void readSMS(){
		
	}
	
	public void analyzeSMS(){
		
	}
	
	public void getTransactionDetails(){
		
	}
	
	public void storeTransactionDetails(){
		
	}
	
	

}
