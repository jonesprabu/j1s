package com.j1s.expenseanalyser.accounts;

import com.j1s.expenseanalyser.common.SavingsBankAccount;

public class IOBBankSBAccount extends SavingsBankAccount {

}
