package com.j1s.expenseanalyser.accounts;

import com.j1s.expenseanalyser.common.CreditCardAccount;

public class CitiBankCCAccount extends CreditCardAccount {

}
