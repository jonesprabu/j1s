package com.j1s.expenseanalyser.accounts;

import com.j1s.expenseanalyser.common.CreditCardAccount;

public class HDFCBankCCAccount extends CreditCardAccount {

}
